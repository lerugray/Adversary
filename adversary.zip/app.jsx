// Main app — composes hero, palette, sprites, level schematics, do/don't, SKILL.md embed

const { useState, useEffect, useMemo, useRef } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "featuredLevel": 1,
  "crt": true,
  "showOryx": true
}/*EDITMODE-END*/;

// ===== NES palette master table =====
const NES_MASTER = [
  { idx: '$0F', hex: '#000000', role: 'True black — silhouettes' },
  { idx: '$00', hex: '#747474', role: 'Stone mid-tone' },
  { idx: '$10', hex: '#bcbcbc', role: 'Stone highlight' },
  { idx: '$30', hex: '#fcfcfc', role: 'Off-white, glints, UI' },
  { idx: '$06', hex: '#a40000', role: 'Blood crimson — hazard, boss' },
  { idx: '$16', hex: '#d82800', role: 'Fire orange — bonfire core' },
  { idx: '$17', hex: '#b84000', role: 'Ember mid' },
  { idx: '$27', hex: '#fca044', role: 'Amber — Ashen Hearth' },
  { idx: '$37', hex: '#fccc9c', role: 'Pale amber' },
  { idx: '$08', hex: '#503000', role: 'Brown-black — grass, wood' },
  { idx: '$18', hex: '#884000', role: 'Rust — Iron Passage' },
  { idx: '$28', hex: '#cc6800', role: 'Rust highlight' },
  { idx: '$01', hex: '#241488', role: 'Deep indigo — night sky' },
  { idx: '$11', hex: '#0058f8', role: 'Cold blue — fog' },
  { idx: '$21', hex: '#3cbcfc', role: 'Ice blue — Pale Spire' },
  { idx: '$31', hex: '#a4e4fc', role: 'Pale ice — stained glass' },
  { idx: '$0C', hex: '#007800', role: 'Dead green — lichen' },
];

function Swatch({ idx, hex, role }) {
  return (
    <div className="swatch">
      <div className="swatch-chip" style={{ background: hex }} />
      <div className="swatch-meta">
        <div className="swatch-idx">{idx}</div>
        <div className="swatch-hex">{hex}</div>
        <div className="swatch-role">{role}</div>
      </div>
    </div>
  );
}

function SubPalette({ label, indices, colors }) {
  return (
    <div>
      <div style={{ fontSize: 11, color: '#8a8578', marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.1em' }}>{label}</div>
      <div className="subpal">
        {colors.map((c, i) => (
          <div key={i} className="subpal-chip" style={{ background: c }}>
            <span>{indices[i]}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ===== Hero =====
function Hero({ tweaks, setTweak }) {
  const level = LEVELS[tweaks.featuredLevel - 1];
  const LevelEl = level.el;
  return (
    <div className="masthead">
      <div className="masthead-row">
        <span>adversary // design-skill manual</span>
        <span>rev. 01 · 256×240 · cart-id 00A7</span>
      </div>
      <h1 className="title">ADVERSARY</h1>
      <div className="subtitle">A lost 1984–86 NES cartridge.</div>
      <p className="lede">
        Single-screen platformer. <span style={{color:'#fca044'}}>Donkey Kong</span> structure,
        <span style={{color:'#bcbcbc'}}> Castlevania 1</span> atmosphere,
        <span style={{color:'#a4e4fc'}}> Dark Souls</span> thematic remix.
        Four hand-built levels. This manual is the aesthetic + level-design skill
        that every session routes through. Route all level-construction here first.
      </p>

      <div className="meta-grid">
        <div className="meta-cell"><div className="meta-key">resolution</div><div className="meta-val">256×240</div></div>
        <div className="meta-cell"><div className="meta-key">palette</div><div className="meta-val">NES-64</div></div>
        <div className="meta-cell"><div className="meta-key">levels</div><div className="meta-val">4</div></div>
        <div className="meta-cell"><div className="meta-key">scroll</div><div className="meta-val">none</div></div>
      </div>

      <div className="hero-level">
        <div>
          <LevelEl />
        </div>
        <div>
          <div style={{ fontSize: 11, color: '#8a8578', letterSpacing: '0.12em', textTransform: 'uppercase' }}>featured level · {level.code}</div>
          <h3>{level.name}</h3>
          <div className="name-sub">{level.ref}</div>
          <div className="thesis-big">"{level.thesis}"</div>
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 11, color: '#8a8578', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Mood</div>
            <div style={{ fontSize: 13 }}>{level.mood}</div>
          </div>
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 11, color: '#8a8578', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Complexity ceiling</div>
            <div style={{ fontSize: 13, color: '#fca044' }}>{level.ceiling}</div>
          </div>
          <SubPalette label="Sub-palette" indices={level.palette.map(p=>p.split(' • ')[0])} colors={level.palette.map(p=>p.split(' • ')[1])} />
        </div>
      </div>

      <div className="level-tabs">
        {LEVELS.map(l => (
          <button
            key={l.id}
            className={`level-tab ${tweaks.featuredLevel === l.id ? 'active' : ''}`}
            onClick={() => setTweak('featuredLevel', l.id)}
          >
            <span className="num">{l.code}</span>
            <span className="tname">{l.name}</span>
            <span>{l.ref}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ===== Sections =====
function SectionHead({ num, title, desc }) {
  return (
    <div className="section-head">
      <span className="section-num">§{num}</span>
      <h2 className="section-title">{title}</h2>
      <div className="section-desc">{desc}</div>
    </div>
  );
}

function PaletteSection() {
  return (
    <section id="palette">
      <SectionHead num="1" title="Palette" desc="NES 64-color gamut. Index is source of truth; hex is an approximation for the web." />
      <div className="block">
        <div className="block-head">Master swatches</div>
        <div className="block-sub">17 selected — the full working set for all 4 levels</div>
        <div className="palette-grid">
          {NES_MASTER.map(s => <Swatch key={s.idx} {...s} />)}
        </div>
      </div>

      <div className="block">
        <div className="block-head">Per-level sub-palettes</div>
        <div className="block-sub">NES sprites run on 4-color sub-palettes. Index 0 is transparent.</div>
        <div className="grid-2">
          {LEVELS.map(l => (
            <div key={l.id} style={{ border: '1px solid #2a2832', padding: 14, background: '#0a0a0f' }}>
              <div style={{ fontFamily: 'VT323', fontSize: 20, color: '#fca044' }}>{l.code} · {l.name}</div>
              <div style={{ fontSize: 11, color: '#8a8578', marginBottom: 10 }}>{l.ref}</div>
              <SubPalette label="dominant" indices={l.palette.map(p=>p.split(' • ')[0])} colors={l.palette.map(p=>p.split(' • ')[1])} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function SpriteSection() {
  return (
    <section id="sprites">
      <SectionHead num="2" title="Sprites" desc="2–3 solid colors plus transparency. Hard pixel edges. Chunky DK/Spelunker proportions." />

      <div className="grid-3">
        <div className="sprite-specimen">
          <PixelGrid art={SPRITES.PLAYER} scale={10} />
          <div className="sprite-name">Player · 16×16</div>
          <div className="sprite-notes">head 6px · torso 5px · legs 5px<br/>4 anim frames max</div>
        </div>
        <div className="sprite-specimen">
          <PixelGrid art={SPRITES.ARCHER} scale={10} />
          <div className="sprite-name">Archer · L2</div>
          <div className="sprite-notes">pure silhouette · 1px eye glint<br/>telegraph frame visible only</div>
        </div>
        <div className="sprite-specimen">
          <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height: 180 }}>
            <PixelGrid art={SPRITES.BARREL} scale={16} />
          </div>
          <div className="sprite-name">Barrel · L1</div>
          <div className="sprite-notes">8×8 · DK homage<br/>rolls from shrine @ 2s cadence</div>
        </div>
      </div>

      <div className="grid-3" style={{ marginTop: 20 }}>
        <div className="sprite-specimen">
          <PixelGrid art={SPRITES.PENDULUM} scale={10} />
          <div className="sprite-name">Pendulum · L3</div>
          <div className="sprite-notes">silhouette · 1px leading-edge glint<br/>40px arc · period 120 frames</div>
        </div>
        <div className="sprite-specimen">
          <PixelGrid art={SPRITES.GEAR} scale={10} />
          <div className="sprite-name">Gear · L3</div>
          <div className="sprite-notes">4 rotation frames · 15-frame cadence<br/>contact = death</div>
        </div>
        <div className="sprite-specimen">
          <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height: 180 }}>
            <PixelGrid art={SPRITES.BONFIRE} scale={10} />
          </div>
          <div className="sprite-name">Bonfire — L1</div>
          <div className="sprite-notes">brightest element on screen<br/>3-frame flicker loop</div>
        </div>
      </div>

      <div className="grid-3" style={{ marginTop: 20 }}>
        <div className="sprite-specimen">
          <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height: 180 }}>
            <PixelGrid art={SPRITES.PORTCULLIS} scale={10} />
          </div>
          <div className="sprite-name">Portcullis — L2</div>
          <div className="sprite-notes">flanking torches = bright signal<br/>checkpoint anchor</div>
        </div>
        <div className="sprite-specimen">
          <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height: 180 }}>
            <PixelGrid art={SPRITES.IRON_GATE} scale={10} />
          </div>
          <div className="sprite-name">Iron Gate — L3</div>
          <div className="sprite-notes">abstract solid rectangle<br/>almost UI-like</div>
        </div>
        <div className="sprite-specimen">
          <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height: 180 }}>
            <PixelGrid art={SPRITES.ALTAR} scale={10} />
          </div>
          <div className="sprite-name">Altar — L4</div>
          <div className="sprite-notes">activates post-boss only<br/>stained-glass shaft</div>
        </div>
      </div>
    </section>
  );
}

function LevelSection() {
  return (
    <section id="levels">
      <SectionHead num="3" title="Level templates" desc="All four levels fit one 256×240 screen. Vertical traversal is the core verb. Player starts bottom, checkpoint tops." />

      <div className="grid-2">
        {LEVELS.map(l => {
          const LevelEl = l.el;
          return (
            <div key={l.id} className="schematic-wrap">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12, padding: '4px 4px 8px' }}>
                <div style={{ minWidth: 0, flex: 1 }}>
                  <div style={{ fontFamily: 'VT323', fontSize: 20, color: '#fca044', lineHeight: 1.1 }}>{l.code} · {l.name}</div>
                  <div style={{ fontSize: 10, color: '#8a8578', textTransform: 'uppercase', letterSpacing: '0.1em', marginTop: 2 }}>{l.ref}</div>
                </div>
                <div style={{ fontSize: 9, color: '#8a8578', whiteSpace: 'nowrap', flexShrink: 0, paddingTop: 4, letterSpacing: '0.05em' }}>256×240</div>
              </div>
              <LevelEl />
              <div className="level-thesis">Thesis: "{l.thesis}"</div>
              <dl className="schematic-meta">
                <dt>Mood</dt><dd>{l.mood}</dd>
                <dt>Ceiling</dt><dd style={{ color: '#fca044' }}>{l.ceiling}</dd>
              </dl>
            </div>
          );
        })}
      </div>
    </section>
  );
}

function ChallengeSection() {
  const principles = [
    { n: '7.1', h: 'One idea per level', body: 'Each level teaches or tests ONE mechanical idea. L1 = rhythm. L2 = commitment under occlusion. L3 = timing. L4 = boss patterns. If a mechanic does not serve the level\'s idea, it belongs in a different level or it belongs cut.' },
    { n: '7.2', h: 'Every platform justifies itself', body: 'For every platform placed, annotate in code: [traversal | hazard-dodge | rest | bait]. If none apply, delete it.' },
    { n: '7.3', h: 'The 3-second readability test', body: 'A player glancing for 3 seconds must identify start, goal, hazards, path. If not, the composition is wrong — not the palette, not the sprites.' },
    { n: '7.4', h: 'Checkpoints are promises', body: 'Top of screen. Brightest element. Never mid-level. Nothing decorative should be brighter.' },
    { n: '7.5', h: 'Single-screen discipline', body: 'Needs scrolling? Different game. Reshape the idea to fit 256×240 or cut it.' },
    { n: '7.6', h: 'Frame-count all timings', body: 'Pendulum period = 120 frames, not 2.0 seconds. Never setTimeout. Never real-time. Keeps gameplay feel locked to pre-emulator cadence.' },
    { n: '7.7', h: 'Enemies are punctuation', body: 'A screen with four enemies is noisy. One enemy in the right place is a sentence. Target 0–2 enemies per level.' },
  ];
  return (
    <section id="principles">
      <SectionHead num="4" title="Challenge design" desc="The most important section. Read before every level-design session. Each challenge gets carefully considered." />
      <div className="grid-2">
        {principles.map(p => (
          <div key={p.n} className="block" style={{ margin: 0 }}>
            <div style={{ display: 'flex', gap: 12, alignItems: 'baseline' }}>
              <div className="section-num">{p.n}</div>
              <div className="block-head" style={{ margin: 0 }}>{p.h}</div>
            </div>
            <div style={{ marginTop: 10, fontSize: 12, color: '#d8d2c0' }}>{p.body}</div>
          </div>
        ))}
      </div>

      <div className="block" style={{ marginTop: 20, borderColor: '#884000' }}>
        <div className="block-head" style={{ color: '#fccc9c' }}>Level-construction workflow</div>
        <div className="block-sub">Follow in order. Do not skip steps.</div>
        <ol style={{ margin: 0, paddingLeft: 24, fontSize: 12, lineHeight: 1.8 }}>
          <li>Name the level's ONE idea. Write it at the top of the scene file.</li>
          <li>Pick a sub-palette from §1. Do not invent one.</li>
          <li>Sketch the 256×240 grid. ASCII in the scene comment.</li>
          <li>Place the checkpoint FIRST (top, brightest).</li>
          <li>Place the player start (bottom, usually x=24).</li>
          <li>Draw the critical path. Every platform on it is justified (§7.2).</li>
          <li>Add the ONE hazard/enemy type. Obey the per-level ceiling.</li>
          <li>Run the 3-second readability test (§7.3).</li>
          <li>Implement in Phaser with frame-count timers (§7.6).</li>
          <li>Grep for §8 violations. Fix before committing.</li>
        </ol>
      </div>
    </section>
  );
}

function DoDontSection() {
  const rows = [
    ['Hard pixel edges',         'Anti-aliasing',       'antialias: true · smoothPixelArt · imageSmoothing'],
    ['2–3 colors per sprite',    'Gradients',           'linearGradient · fillGradient · CSS gradient on sprite'],
    ['Nearest-neighbor scaling', 'Bilinear',            'FILTER_LINEAR · scaleMode: 1'],
    ['NES palette hex only',     'Off-gamut color',     'any hex not in §1.1 master table'],
    ['2–4 animation frames',     'Tweened motion',      'this.tweens.add · ease: · lerp('],
    ['Single screen',            'Scrolling camera',    'startFollow · scrollX · setBounds(>256,>240)'],
    ['Solid alpha',              'Partial transparency','setAlpha(0. · alpha: 0.'],
    ['Integer positions',        'Sub-pixel',           'setPosition without Math.round · translateX(0.5px)'],
    ['Frame-count timers',       'Real-time timers',    'setTimeout · Phaser.Time.Delay.ms'],
    ['Silhouette hazards',       'Textured hazards',    'hazard PNG > 3 unique colors'],
  ];
  return (
    <section id="dodont">
      <SectionHead num="5" title="Do / Avoid" desc="Grep-ready. Claude Code should catch violations automatically." />
      <div className="block" style={{ padding: 0 }}>
        <table className="doc-table">
          <thead>
            <tr><th style={{ color: '#fca044' }}>Do</th><th style={{ color: '#a40000' }}>Avoid</th><th>Grep pattern</th></tr>
          </thead>
          <tbody>
            {rows.map(([d, a, g], i) => (
              <tr key={i}>
                <td>{d}</td>
                <td style={{ color: '#8a8578' }}>{a}</td>
                <td>{g.split(' · ').map((p, j) => <span key={j} className="grep-chip">{p}</span>)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="dodont">
        <div className="do">
          <div className="h">DO — silhouette hazard</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <PixelGrid art={SPRITES.PENDULUM} scale={7} />
            <div style={{ fontSize: 11, color: '#d8d2c0' }}>
              Pure $0F body<br/>
              One $30 pixel on leading edge<br/>
              Reads in one glance<br/>
              Silhouette-first
            </div>
          </div>
        </div>
        <div className="dont">
          <div className="h">AVOID — textured hazard</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            {/* Bad version — multi-color, gradient-looking, alpha */}
            <div style={{
              width: 112, height: 112,
              background: 'linear-gradient(135deg, #888, #222, #555, #000)',
              boxShadow: '0 4px 20px rgba(255,160,68,0.4)',
              border: '1px solid #2a2832',
              opacity: 0.92,
            }} />
            <div style={{ fontSize: 11, color: '#8a8578' }}>
              Gradient shading<br/>
              Soft shadow<br/>
              Alpha = 0.92<br/>
              Fails in 1 second
            </div>
          </div>
        </div>
      </div>

      <div className="block oryx-only">
        <div className="block-head">Architecture smells — stop and reconsider</div>
        <div className="block-sub">If you see any of these in a Phaser scene class</div>
        <pre style={{ margin: 0, padding: 16, background: '#000', border: '1px solid #2a2832', fontSize: 11, lineHeight: 1.7, color: '#d8d2c0', overflow: 'auto' }}>
{`this.cameras.main.startFollow(player)         // scrolling
scene.add.image(...).setScale(1.5)            // sub-integer scale
sprite.setTint(0x...)                         // use palette swap, not tint
this.physics.world.setBounds(0, 0, 512, 480)  // oversized world
sprite.anims.create({ duration: 1000 })       // ms, not frames
setTimeout(() => {...}, 2000)                 // real-time, not frames`}
        </pre>
      </div>
    </section>
  );
}

function SkillEmbedSection() {
  const [copied, setCopied] = useState(false);
  const [skillText, setSkillText] = useState('Loading SKILL.md …');

  useEffect(() => {
    fetch('SKILL.md').then(r => r.text()).then(setSkillText).catch(() => {
      setSkillText('— unable to load SKILL.md; see the file in the project root —');
    });
  }, []);

  const copy = () => {
    navigator.clipboard?.writeText(skillText).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    });
  };

  return (
    <section id="skill">
      <SectionHead num="6" title="SKILL.md — text source" desc="Copy-paste target. Drop into Adversary/.claude/skills/adversary-aesthetic.md" />
      <div className="copy-row">
        <span>{skillText.split('\n').length} lines · {Math.round(skillText.length/1000)}KB</span>
        <button className="copy-btn" onClick={copy}>{copied ? '✓ copied' : 'copy'}</button>
      </div>
      <pre className="skill-embed">{skillText}</pre>
    </section>
  );
}

function App() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);

  useEffect(() => {
    document.body.classList.toggle('no-crt', !tweaks.crt);
    document.body.classList.toggle('no-oryx', !tweaks.showOryx);
  }, [tweaks.crt, tweaks.showOryx]);

  return (
    <>
      <div className="crt-overlay" />
      <div className="corner-index">
        <div><span className="k">§1</span> palette</div>
        <div><span className="k">§2</span> sprites</div>
        <div><span className="k">§3</span> levels</div>
        <div><span className="k">§4</span> challenge</div>
        <div><span className="k">§5</span> do/avoid</div>
        <div><span className="k">§6</span> SKILL.md</div>
      </div>
      <div className="doc">
        <Hero tweaks={tweaks} setTweak={setTweak} />
        <PaletteSection />
        <SpriteSection />
        <LevelSection />
        <ChallengeSection />
        <DoDontSection />
        <SkillEmbedSection />
        <div className="doc-foot">
          <span>adversary // aesthetic + level-design skill · synced with claude-design-brief.md</span>
          <span>press tab ▸ tweaks</span>
        </div>
      </div>
      <TweaksPanel title="Tweaks">
        <TweakSection label="Display" />
        <TweakToggle label="CRT scanlines" value={tweaks.crt}
          onChange={v => setTweak('crt', v)} />
        <TweakToggle label="Oryx guidance visible" value={tweaks.showOryx}
          onChange={v => setTweak('showOryx', v)} />
        <TweakSection label="Featured level" />
        <TweakRadio value={tweaks.featuredLevel}
          options={LEVELS.map(l => ({ value: l.id, label: `${l.code} — ${l.name}` }))}
          onChange={v => setTweak('featuredLevel', v)} />
      </TweaksPanel>
    </>
  );
}

const root = ReactDOM.createRoot(document.getElementById('app'));
root.render(<App />);
