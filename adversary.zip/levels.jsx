// Level schematic renderer — draws a 256×240 level grid with platforms, hazards, checkpoints
// All positions are in 256×240 source pixels; CSS % coordinates convert them.

const L1_PALETTE = {
  bg: '#0a0a0f',
  ground: '#503000',      // $08
  ledge: '#884000',       // $18
  accent: '#fca044',      // $27
  dim: '#503000',
};
const L2_PALETTE = {
  bg: '#0a0a12',
  ground: '#241488',      // $01
  ledge: '#747474',       // $00
  accent: '#bcbcbc',      // $10
  dim: '#0058f8',
};
const L3_PALETTE = {
  bg: '#0a0a0f',
  ground: '#503000',
  ledge: '#884000',       // $18
  accent: '#cc6800',      // $28
  dim: '#747474',
};
const L4_PALETTE = {
  bg: '#08081a',
  ground: '#241488',      // $01
  ledge: '#747474',
  accent: '#3cbcfc',      // $21
  dim: '#0058f8',
};

// Helper — position a rect in 256x240 space as %.
function rect({x, y, w, h, color, outline, title, style={}}) {
  return {
    position: 'absolute',
    left: `${(x/256)*100}%`,
    top: `${(y/240)*100}%`,
    width: `${(w/256)*100}%`,
    height: `${(h/240)*100}%`,
    background: color,
    outline: outline ? `1px solid ${outline}` : 'none',
    boxShadow: 'none',
    imageRendering: 'pixelated',
    ...style,
  };
}

function Platform({x, y, w, h=4, palette, oneWay=false, label}) {
  return (
    <div style={rect({
      x, y, w, h,
      color: palette.ledge,
      style: oneWay ? { borderBottom: `2px solid ${palette.bg}` } : {},
    })} />
  );
}
function Ladder({x, y, h, palette}) {
  // 2 rails + horizontal rungs every 6px
  const rungs = [];
  for (let ry = 3; ry < h; ry += 6) {
    rungs.push(
      <div key={ry} style={rect({
        x: x - 2, y: y + ry, w: 8, h: 1,
        color: '#fcfcfc',
      })} />
    );
  }
  return (
    <>
      <div style={rect({ x: x, y, w: 1, h, color: '#fcfcfc' })} />
      <div style={rect({ x: x+3, y, w: 1, h, color: '#fcfcfc' })} />
      {rungs}
    </>
  );
}
function Hazard({x, y, w, h, color, glint}) {
  return (
    <>
      <div style={rect({ x, y, w, h, color })} />
      {glint && <div style={rect({
        x: glint.x, y: glint.y, w: 1, h: 1, color: '#fcfcfc',
      })} />}
    </>
  );
}
function Dot({x, y, color, size=3, label}) {
  return (
    <div style={rect({ x: x-size/2, y: y-size/2, w: size, h: size, color })} />
  );
}
function Checkpoint({x, y, color='#fca044'}) {
  return (
    <>
      {/* Pulsing bright checkpoint */}
      <div style={{
        ...rect({ x: x-8, y: y-8, w: 16, h: 16, color: 'transparent' }),
        background: `radial-gradient(circle, ${color} 10%, transparent 70%)`,
        opacity: 0.5,
      }} />
      <div style={rect({ x: x-4, y: y-4, w: 8, h: 8, color })} />
      <div style={rect({ x: x-2, y: y-2, w: 4, h: 4, color: '#fcfcfc' })} />
    </>
  );
}
function PlayerMark({x, y}) {
  return (
    <>
      <div style={rect({ x: x-3, y: y-4, w: 6, h: 4, color: '#fca044' })} />
      <div style={rect({ x: x-2, y: y, w: 4, h: 3, color: '#a40000' })} />
    </>
  );
}
function Label({x, y, text, accent='#fca044', anchor='left'}) {
  return (
    <div className="sch-label" style={{
      left: anchor === 'right' ? 'auto' : `${(x/256)*100}%`,
      right: anchor === 'right' ? `${((256-x)/256)*100}%` : 'auto',
      top: `${(y/240)*100}%`,
      borderLeftColor: accent,
    }}>{text}</div>
  );
}
function Arrow({x, y, w=1, h=20, color='#fcfcfc', dashed=true}) {
  return (
    <div style={{
      ...rect({ x, y, w, h, color: 'transparent' }),
      borderLeft: `1px ${dashed ? 'dashed' : 'solid'} ${color}`,
      opacity: 0.5,
    }} />
  );
}

// ============ LEVEL 1 — ASHEN HEARTH ============
function LevelOne() {
  const p = L1_PALETTE;
  return (
    <div className="schematic" style={{ background: '#140800' }}>
      {/* Ambient warm glow backdrop */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(ellipse at 50% 20%, rgba(252,160,68,0.18), transparent 55%)',
      }} />
      {/* Decorative arches (silhouettes) */}
      <div style={rect({ x: 180, y: 12, w: 24, h: 30, color: 'rgba(80,48,0,0.55)' })} />
      <div style={rect({ x: 30, y: 18, w: 18, h: 24, color: 'rgba(80,48,0,0.45)' })} />
      {/* Shrine platform (top) */}
      <Platform x={40} y={48} w={160} h={4} palette={p} />
      <Checkpoint x={128} y={32} color="#fca044" />
      <Label x={10} y={6} text="☼ BONFIRE (128, 32)" />

      <Ladder x={200} y={52} h={44} palette={p} />
      <Platform x={80} y={96} w={120} h={3} palette={p} oneWay />
      <Label x={80} y={88} text="y=96 one-way" accent="#884000" />

      <Ladder x={48} y={100} h={28} palette={p} />
      <Platform x={48} y={128} w={72} h={3} palette={p} oneWay />
      {/* Barrel in motion */}
      <Hazard x={140} y={146} w={6} h={6} color="#d82800" glint={{x:141, y:147}} />
      <Label x={140} y={138} text="○ barrel" accent="#d82800" />

      {/* Ground with gap */}
      <Platform x={0} y={176} w={120} h={8} palette={p} />
      <Platform x={140} y={176} w={116} h={8} palette={p} />
      <Label x={122} y={180} text="gap" accent="#fca044" />

      <Ladder x={48} y={184} h={24} palette={p} />
      <Platform x={0} y={208} w={80} h={3} palette={p} oneWay />

      {/* Ground floor */}
      <Platform x={0} y={232} w={256} h={8} palette={p} />
      <PlayerMark x={24} y={226} />
      <Label x={30} y={228} text="▲ START (24, 224)" accent="#fcfcfc" />
    </div>
  );
}

// ============ LEVEL 2 — CRESTHOLLOW ============
function LevelTwo() {
  const p = L2_PALETTE;
  return (
    <div className="schematic" style={{ background: '#050510' }}>
      {/* Sky */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'linear-gradient(180deg, #241488 0%, #0a0a1e 60%, #050510 100%)',
        opacity: 0.7,
      }} />
      {/* Distant tenement silhouettes */}
      <div style={rect({ x: 0, y: 24, w: 40, h: 20, color: '#111125' })} />
      <div style={rect({ x: 60, y: 32, w: 30, h: 14, color: '#111125' })} />
      <div style={rect({ x: 220, y: 22, w: 36, h: 22, color: '#111125' })} />

      {/* Portcullis checkpoint top-right */}
      <div style={rect({ x: 192, y: 8, w: 32, h: 20, color: '#884000' })} />
      <Checkpoint x={208} y={18} color="#fccc9c" />
      <Label x={160} y={4} text="▮ PORTCULLIS (200, 16)" />

      {/* Tenement roof */}
      <Platform x={0} y={40} w={160} h={4} palette={p} />
      {/* Archer 1 */}
      <div style={rect({ x: 46, y: 32, w: 6, h: 8, color: '#000' })} />
      <div style={rect({ x: 50, y: 35, w: 1, h: 1, color: '#fcfcfc' })} />
      <Label x={56} y={30} text="▲ archer (48, 56)" accent="#a40000" />

      <Platform x={0} y={72} w={56} h={3} palette={p} oneWay />
      <Platform x={80} y={72} w={96} h={3} palette={p} oneWay />

      {/* Fog band */}
      <div style={{
        ...rect({ x: 0, y: 112, w: 256, h: 16, color: 'transparent' }),
        background: 'repeating-linear-gradient(90deg, rgba(0,88,248,0.35) 0 2px, transparent 2px 6px), linear-gradient(180deg, rgba(0,88,248,0.15), rgba(0,88,248,0.25), rgba(0,88,248,0.15))',
      }} />
      <Label x={6} y={112} text=". . FOG y=112–128 . ." accent="#0058f8" />

      <Platform x={100} y={152} w={80} h={3} palette={p} oneWay />
      {/* Archer 2 */}
      <div style={rect({ x: 214, y: 152, w: 6, h: 8, color: '#000' })} />
      <div style={rect({ x: 218, y: 155, w: 1, h: 1, color: '#fcfcfc' })} />
      <Label x={180} y={146} text="▲ archer (216, 160)" accent="#a40000" />

      <Platform x={0} y={184} w={80} h={3} palette={p} oneWay />
      <Platform x={110} y={184} w={100} h={3} palette={p} oneWay />

      <Ladder x={40} y={188} h={40} palette={p} />
      <Ladder x={172} y={156} h={60} palette={p} />

      <Platform x={0} y={232} w={256} h={8} palette={p} />
      <PlayerMark x={24} y={226} />
      <Label x={30} y={228} text="▲ START" accent="#fcfcfc" />
    </div>
  );
}

// ============ LEVEL 3 — IRON PASSAGE ============
function LevelThree() {
  const p = L3_PALETTE;
  return (
    <div className="schematic" style={{ background: '#0a0806' }}>
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(ellipse at 50% 50%, rgba(136,64,0,0.12), transparent 70%)',
      }} />
      {/* Iron gate (checkpoint) top center */}
      <div style={rect({ x: 112, y: 8, w: 32, h: 22, color: '#fcfcfc' })} />
      <Checkpoint x={128} y={24} color="#fcfcfc" />
      <Label x={146} y={6} text="▣ IRON GATE (128, 24)" />

      <Platform x={0} y={48} w={112} h={4} palette={p} />
      <Platform x={144} y={48} w={112} h={4} palette={p} />

      {/* Pendulum 1 */}
      <div style={rect({ x: 128, y: 52, w: 1, h: 4, color: '#fcfcfc' })} />
      <Hazard x={120} y={72} w={16} h={24} color="#000" glint={{x:134, y:94}} />
      <Label x={138} y={60} text="↕ pendulum (128)" accent="#a40000" />

      <Platform x={0} y={104} w={96} h={3} palette={p} oneWay />
      <Platform x={132} y={104} w={124} h={3} palette={p} oneWay />

      {/* Gear */}
      <div style={{
        ...rect({ x: 72, y: 120, w: 20, h: 20, color: 'transparent' }),
        border: '2px solid #884000',
        borderRadius: '0',
        boxShadow: 'inset 0 0 0 3px #cc6800',
      }} />
      <Label x={6} y={125} text="◉ gear (80, 128)" accent="#cc6800" />

      <Platform x={0} y={144} w={88} h={3} palette={p} oneWay />
      <Platform x={120} y={144} w={80} h={3} palette={p} oneWay />

      {/* Pendulum 2 */}
      <div style={rect({ x: 176, y: 107, w: 1, h: 4, color: '#fcfcfc' })} />
      <Hazard x={168} y={152} w={16} h={24} color="#000" glint={{x:182, y:174}} />
      <Label x={188} y={156} text="↕ pendulum (176)" accent="#a40000" />

      <Ladder x={16} y={148} h={60} palette={p} />

      {/* Elevator */}
      <div style={rect({ x: 196, y: 176, w: 24, h: 4, color: '#884000', outline: '#fcfcfc' })} />
      <Arrow x={208} y={108} h={68} color="#fcfcfc" dashed />
      <Label x={192} y={170} text="[▬▬] elevator" accent="#cc6800" />

      <Platform x={0} y={200} w={88} h={3} palette={p} oneWay />
      <Platform x={120} y={200} w={80} h={3} palette={p} oneWay />

      <Platform x={0} y={232} w={256} h={8} palette={p} />
      <PlayerMark x={24} y={226} />
      <Label x={30} y={228} text="▲ START" accent="#fcfcfc" />
    </div>
  );
}

// ============ LEVEL 4 — PALE SPIRE ============
function LevelFour() {
  const p = L4_PALETTE;
  return (
    <div className="schematic" style={{ background: '#05051a' }}>
      <div style={{
        position: 'absolute', inset: 0,
        background: 'linear-gradient(180deg, #241488 0%, #0a0a2e 50%, #05051a 100%)',
      }} />
      {/* Stained glass windows */}
      <div style={rect({ x: 40, y: 16, w: 12, h: 40, color: '#3cbcfc' })} />
      <div style={rect({ x: 42, y: 20, w: 8, h: 36, color: '#a4e4fc' })} />
      <div style={rect({ x: 112, y: 12, w: 16, h: 48, color: '#3cbcfc' })} />
      <div style={rect({ x: 114, y: 16, w: 12, h: 44, color: '#a4e4fc' })} />
      <div style={rect({ x: 118, y: 20, w: 4, h: 36, color: '#3cbcfc' })} />
      <div style={rect({ x: 204, y: 16, w: 12, h: 40, color: '#3cbcfc' })} />
      <div style={rect({ x: 206, y: 20, w: 8, h: 36, color: '#a4e4fc' })} />
      <Label x={132} y={4} text="STAINED GLASS" accent="#3cbcfc" />

      {/* Columns */}
      <div style={rect({ x: 16, y: 72, w: 8, h: 140, color: '#747474' })} />
      <div style={rect({ x: 60, y: 72, w: 8, h: 140, color: '#747474' })} />
      <div style={rect({ x: 188, y: 72, w: 8, h: 140, color: '#747474' })} />
      <div style={rect({ x: 232, y: 72, w: 8, h: 140, color: '#747474' })} />

      {/* Balcony */}
      <Platform x={0} y={72} w={256} h={4} palette={p} />

      {/* Hollow King silhouette */}
      <div style={rect({ x: 116, y: 128, w: 24, h: 32, color: '#000' })} />
      <div style={rect({ x: 122, y: 134, w: 4, h: 2, color: '#a40000' })} />
      <div style={rect({ x: 130, y: 134, w: 4, h: 2, color: '#a40000' })} />
      {/* Throne */}
      <div style={rect({ x: 110, y: 140, w: 36, h: 24, color: '#505050' })} />
      <div style={rect({ x: 116, y: 128, w: 24, h: 32, color: '#000' })} />
      <Label x={150} y={132} text="▓ HOLLOW KING (120, 128)" accent="#a40000" />

      {/* Arena floor */}
      <Platform x={0} y={160} w={256} h={4} palette={p} />

      {/* Altar */}
      <Checkpoint x={128} y={184} color="#a4e4fc" />
      <Label x={136} y={178} text="▒ altar (128, 180)" accent="#3cbcfc" />

      {/* Ground */}
      <Platform x={0} y={208} w={256} h={32} palette={p} />
      <PlayerMark x={24} y={226} />
      <Label x={30} y={228} text="▲ START" accent="#fcfcfc" />
    </div>
  );
}

const LEVELS = [
  {
    id: 1, code: 'L1', name: 'The Ashen Hearth', ref: 'Firelink Shrine',
    thesis: 'Teach the verbs.',
    palette: ['#0F • #000000', '#08 • #503000', '#17 • #b84000', '#27 • #fca044'],
    mood: 'Melancholy dawn after defeat.',
    ceiling: 'ONE hazard type. ONE gap. TWO ladders.',
    el: LevelOne,
  },
  {
    id: 2, code: 'L2', name: 'Cresthollow', ref: 'Undead Burg',
    thesis: 'Commit through impaired visibility.',
    palette: ['#0F • #000000', '#00 • #747474', '#10 • #bcbcbc', '#01 • #241488'],
    mood: 'Abandoned city waiting to be reclaimed.',
    ceiling: 'TWO archers max. ONE fog band. ZERO killable enemies.',
    el: LevelTwo,
  },
  {
    id: 3, code: 'L3', name: 'The Iron Passage', ref: "Sen's Fortress",
    thesis: 'The level is the enemy.',
    palette: ['#0F • #000000', '#00 • #747474', '#18 • #884000', '#28 • #cc6800'],
    mood: 'Industrial hostility, timing-puzzle tension.',
    ceiling: 'THREE timed threats max. ZERO enemies. ALL timers in frames.',
    el: LevelThree,
  },
  {
    id: 4, code: 'L4', name: 'The Pale Spire', ref: 'Anor Londo',
    thesis: 'Stillness, then storm.',
    palette: ['#0F • #000000', '#00 • #747474', '#01 • #241488', '#21 • #3cbcfc'],
    mood: 'Solemn culmination. Quietest level until the boss engages.',
    ceiling: 'TWO platforms. ONE boss. ZERO environmental hazards in-fight.',
    el: LevelFour,
  },
];

Object.assign(window, { LEVELS });
