// Pixel sprite renderer — takes a 2D array of color keys, renders as CSS grid
// No SVG, no hand-drawn shapes. Just colored cells.

const PALETTE = {
  '.': 'transparent',
  '0': '#000000',      // $0F
  's': '#747474',      // $00 stone
  'S': '#bcbcbc',      // $10 stone-hi
  'W': '#fcfcfc',      // $30 moon
  'r': '#a40000',      // $06 crimson
  'o': '#d82800',      // $16 ember
  'O': '#b84000',      // $17 ember-mid
  'a': '#fca044',      // $27 amber
  'A': '#fccc9c',      // $37 amber-hi
  'b': '#503000',      // $08 brown-black
  'u': '#884000',      // $18 rust
  'U': '#cc6800',      // $28 rust-hi
  'n': '#241488',      // $01 night
  'c': '#0058f8',      // $11 cold
  'i': '#3cbcfc',      // $21 ice
  'I': '#a4e4fc',      // $31 ice-hi
  'g': '#007800',      // $0C dead green
};

function PixelGrid({ art, scale = 6, bg = '#000' }) {
  const rows = art.length;
  const cols = art[0].length;
  const cells = [];
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      const ch = art[y][x];
      const color = PALETTE[ch] ?? 'transparent';
      cells.push(
        <div key={`${x}-${y}`} style={{
          background: color,
          width: scale, height: scale,
        }} />
      );
    }
  }
  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: `repeat(${cols}, ${scale}px)`,
      gridTemplateRows: `repeat(${rows}, ${scale}px)`,
      background: bg,
      imageRendering: 'pixelated',
      padding: scale,
      border: '1px solid #2a2832',
    }}>{cells}</div>
  );
}

// ===== Player character — 16x16, small DK/Spelunker proportions =====
// big head (top 7 rows), stubby torso (5 rows), short legs (4 rows)
const PLAYER = [
  '................',
  '....000000......',
  '...0aaaaaa0.....',   // helmet
  '..0aaAAaaaa0....',
  '..0aW00W0aaa0...',   // eyes
  '..0aaaaaaaaa0...',
  '...0aaaaaa0.....',
  '....0oooo0......',   // scarf
  '...0oWWWWo0.....',   // torso (red tunic)
  '...0oWooWo0.....',
  '...0oWWWWo0.....',
  '....0.00.0......',
  '....b0..b0......',   // legs
  '....b0..b0......',
  '....bb..bb......',   // boots
  '................',
];

// ===== Hazards =====
const BARREL = [
  '........',
  '.0oooo0.',
  '0oWooWo0',
  '0oooooo0',
  '0oWooWo0',
  '0oooooo0',
  '.0oooo0.',
  '........',
];

const PENDULUM = [
  '................',
  '........0.......',
  '........0.......',
  '.......00.......',
  '.......000......',
  '......0000......',
  '......00000.....',
  '.....000000.....',
  '....0000000W....',  // leading edge highlight
  '....00000000....',
  '.....0000000....',
  '......000000....',
  '.......00000....',
  '........0000....',
  '.........000....',
  '..........0.....',
];

const GEAR = [
  '................',
  '......uuuu......',
  '....UUuuuuUU....',
  '.u.UUuuuuuuUU.u.',
  '.uuUuu0000uuUuu.',
  '..uuuu0000uuuu..',
  '..UUuu0000uuUU..',
  'uuuuuu0000uuuuuu',
  'uuuuuu0000uuuuuu',
  '..UUuu0000uuUU..',
  '..uuuu0000uuuu..',
  '.uuUuu0000uuUuu.',
  '.u.UUuuuuuuUU.u.',
  '....UUuuuuUU....',
  '......uuuu......',
  '................',
];

const ARCHER = [
  '................',
  '.....000000.....',
  '....0000000W....',   // eye glint
  '....00000000....',
  '....00000000....',
  '.....000000.....',
  '......0000......',
  '.....0000000....',
  '....000000000...',
  '....0..000..0...',   // bow
  '...0...000...0..',
  '....0..000..0...',
  '.....0.000.0....',
  '.......000......',
  '......00.00.....',
  '......00.00.....',
];

// ===== Checkpoints =====
const BONFIRE = [
  '................',
  '.......W........',
  '......WoW.......',
  '.....WoOoW......',
  '....WoOAOoW.....',   // core
  '...WoOAWAOoW....',
  '...oOAWWWAOo....',
  '....oOAWAOo.....',
  '.....oOAOo......',
  '......oOo.......',
  '.bbbbbbbbbbbb...',   // logs
  '.b0b0b0b0b0b....',
  '..bbbbbbbbb.....',
  '...bbbbbbb......',
  '................',
  '................',
];

const PORTCULLIS = [
  '................',
  '.uuuuuuuuuuuuuu.',
  '.u000000000000u.',
  '.0u0.u0.u0.u0.0.',
  '.0u0.u0.u0.u0.0.',
  '.0u0.u0.u0.u0.0.',
  '.0u0.u0.u0.u0.0.',
  '.0uuuuuuuuuuuu0.',
  '.0u0.u0.u0.u0.0.',   // lower bars
  '.0u0.u0.u0.u0.0.',
  '.0u0.u0.u0.u0.0.',
  '.0uuuuuuuuuuuu0.',
  '.uoWo........oWo',   // flanking torches (bottom)
  '.ooWo........oWo',
  '.bbbb........bbbb',
  '................',
];

const IRON_GATE = [
  '................',
  '..WWWWWWWWWWWW..',
  '..WWWWWWWWWWWW..',
  '..WWWWWWWWWWWW..',
  '..WWWWWWWWWWWW..',
  '..WWWWWWWWWWWW..',
  '..WWWWWWWWWWWW..',
  '..WWWWWWWWWWWW..',
  '..WWWWWWWWWWWW..',
  '..WWWWWWWWWWWW..',
  '..WWWWWWWWWWWW..',
  '..WWWWWWWWWWWW..',
  '..WWWWWWWWWWWW..',
  '..WWWWWWWWWWWW..',
  '................',
  '................',
];

const ALTAR = [
  '................',
  '.......i........',
  '......iIi.......',
  '.....iIWIi......',
  '....iIWWWIi.....',
  '...iIWWWWWIi....',   // light shaft
  '..iIWWWWWWWIi...',
  '.iIWWWWWWWWWIi..',
  'ssssssssssssssss',   // altar block
  's0SsSsSsSsSsSs0s',
  's0SWWWWWWWWWWS0s',
  's0SssssssssssS0s',
  's0ssssssssssss0s',
  'ssssssssssssssss',
  '................',
  '................',
];

Object.assign(window, {
  PixelGrid, PALETTE,
  SPRITES: {
    PLAYER, BARREL, PENDULUM, GEAR, ARCHER,
    BONFIRE, PORTCULLIS, IRON_GATE, ALTAR,
  },
});
